export const apps__app = {
  buznsi_admin: {
    "id": "buznsi_admin",
    "name": "SafeWra Admin",
    models: {
      
    }
  }
}