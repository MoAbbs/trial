export const sfwra_admin_res = {
  "id": "sfwra_admin_res",
  "name": "Resources",
  "_index": "5",
  "action": {"path": "/user", "key": "route/navigate"},
  "app": "buznsi_admin",
  "icon": {
    type: 'ai',
    name: "AiFillGolden"
  }
}