export const default_val = (val)=>({
  key: 'object/StateSelector',
  path: '',
  default: val,
})
