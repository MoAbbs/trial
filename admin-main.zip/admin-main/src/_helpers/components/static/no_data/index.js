import React, {Component} from 'react'

export default class MainComponent extends Component {
  render() {
    return (
      <h4 style={{textAlign: 'center', width: '100%'}}>
            No Data available
      </h4>
    )
  }
}
