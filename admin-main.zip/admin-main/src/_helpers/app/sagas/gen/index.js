import {uploadModels} from './extra';

export function extra() {
  return {
    // clock,
    uploadModels,
  }
}
