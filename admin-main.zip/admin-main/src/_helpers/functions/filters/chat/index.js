import * as funcs from './main';

export default {...funcs};
