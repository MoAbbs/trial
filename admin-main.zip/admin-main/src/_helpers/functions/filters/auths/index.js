import * as funs from './funs'
export default {
  ...funs,
}
