// import * as soc from './main'
// export default {
//   ...soc,
// }
