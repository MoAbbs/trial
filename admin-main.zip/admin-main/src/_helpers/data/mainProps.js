export default ['style_fun', 'comp', 'comps', 'children', 'click', 'styles', 'wraps', 'component']
