import {lazy} from 'react';
export const button = lazy(()=>import('./button/index.jsx'))
