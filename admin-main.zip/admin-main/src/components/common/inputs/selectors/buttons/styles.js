import appStyles from 'app-global-styles.json'
export default {
  active: {
    container: {
      backgroundColor: appStyles?.colors.primary,
    },
  },
}
