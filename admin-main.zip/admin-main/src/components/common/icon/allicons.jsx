import React, { Component } from 'react'
import * as RiLib from "react-icons/lib";
export const ALL_ICONS = RiLib["IconsManifest"];

export default class allicons extends Component {
  constructor(props){
    super(props);
    // console.log(ALL_ICONS)
  }
  render() {
    return (
      <div>
        
      </div>
    )
  }
}
