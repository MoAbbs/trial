export const inc = (val, old)=>(old+val)
export const dec = (val, old)=>(old-val)