import React from 'react';

const ImgLoader =()=> {

    return(
        <div className ="loader">Loading...</div>
      );
};
export default ImgLoader;