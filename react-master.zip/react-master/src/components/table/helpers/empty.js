import React from 'react'

export default function Empty() {
    return (
        <div>
            <div className="datatable-error">Table is Empty</div>
        </div>
    )
}
