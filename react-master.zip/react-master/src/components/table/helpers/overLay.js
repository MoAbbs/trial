import React from 'react'

export default function OverLay() {
    return (
        <div>
            <div>
                <div>Please wait...</div>
                <div className="loading"></div>
            </div>
        </div>
    )
}
